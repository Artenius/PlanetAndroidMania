import cookielib,base64

a=base64.b64decode("aHR0cDovL3BhbmRyb2lkLmFsdGVydmlzdGEub3JnL3h4eC9tZW51LnBocA==")